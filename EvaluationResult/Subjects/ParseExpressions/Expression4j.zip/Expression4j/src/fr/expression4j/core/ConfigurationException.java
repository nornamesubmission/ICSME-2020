package fr.expression4j.core;

public class ConfigurationException extends Exception {

	private static final long serialVersionUID = 3545235829951049776L;

	public ConfigurationException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ConfigurationException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public ConfigurationException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public ConfigurationException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
