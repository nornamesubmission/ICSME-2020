﻿using org.mariuszgromada.math.mxparser.regressiontesting;

namespace mxparser.runtests {
	class RunTestsReg {
		static void Main(string[] args) {
			RunTest.Start("syn", "api", "reg");
		}
	}
}
