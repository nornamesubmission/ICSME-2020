Math Game
=========

A math game Java GUI program made with Java Swing.

This program is meant to encourage learning math by presenting math problems in a fun and intuitive way.

----------------------------------------------------
Created by students at the Middlesex County Academy for Science, Mathematics, and Engineering Technologies
located in Edison, NJ

Visit the game at http://math-game-mca.github.io
