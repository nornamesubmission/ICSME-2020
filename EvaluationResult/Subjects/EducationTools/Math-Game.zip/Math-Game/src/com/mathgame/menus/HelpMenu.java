package com.mathgame.menus;

/**
 * The HelpMenu class represents the menu that displays help information
 */
public class HelpMenu {
	//TODO Implement the HelpMenu class
}
