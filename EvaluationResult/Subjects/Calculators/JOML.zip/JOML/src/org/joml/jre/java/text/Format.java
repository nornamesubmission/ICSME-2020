package java.text;

import java.io.Serializable;

public abstract class Format implements Serializable, Cloneable {}
