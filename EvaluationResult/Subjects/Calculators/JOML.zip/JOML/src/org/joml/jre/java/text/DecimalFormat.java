package java.text;

public class DecimalFormat extends NumberFormat {

    public DecimalFormat() {
    }
    public DecimalFormat(String pattern) {
    }
    public DecimalFormat (String pattern, DecimalFormatSymbols symbols) {
    }

	public StringBuffer format(double number, StringBuffer toAppendTo, FieldPosition pos) {
		return null;
	}
	public StringBuffer format(long number, StringBuffer toAppendTo, FieldPosition pos) {
		return null;
	}
	public Number parse(String source, ParsePosition parsePosition) {
		return null;
	}
	public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
		return null;
	}
	public Object parseObject(String source, ParsePosition pos) {
		return null;
	}

}
