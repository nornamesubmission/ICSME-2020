This directory contains a script that allows us to collect 'unstable' and unsigned APK file that is build automatically by [Travis CI](https://travis-ci.org/mkulesh/microMathematics) after each commit. Please see [this page](https://github.com/mkulesh/microMathematics/wiki/Autobuild) for more details.

