package sk.styk.martin.bakalarka.execute.arguments;

/**
 * Created by Martin Styk on 20.02.2016.
 */
public enum TaskMode {
    ANALYZE,
    COMPARE,
    STATISTICS
}
