

public abstract interface RegressionFunction2
{
  public abstract double function(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, int paramInt);
}
