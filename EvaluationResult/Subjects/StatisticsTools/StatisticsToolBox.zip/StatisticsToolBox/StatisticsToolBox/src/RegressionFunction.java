
public abstract interface RegressionFunction
{
  public abstract double function(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2);
}
